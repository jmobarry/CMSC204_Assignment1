public class LengthException extends Exception {

    public LengthException(){

    }

    public LengthException(String message){

        super(message);

    }

}
