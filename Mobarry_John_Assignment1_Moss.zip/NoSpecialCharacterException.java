public class NoSpecialCharacterException extends Exception {

    public NoSpecialCharacterException(){

    }

    public NoSpecialCharacterException(String message){
        super(message);
    }

}
